<?php
$conn_error='Could not be connected';//This is to connect to database and to select database.
$mysql_host='localhost';
$mysql_user='root';
$mysql_pass='';
$mysql_db='project';
if(!@mysql_connect($mysql_host,$mysql_user,$mysql_pass) || !@mysql_select_db($mysql_db))
{
  die($conn_error);
}
?>