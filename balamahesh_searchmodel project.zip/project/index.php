<?php
//This is the first page to display.It will contain two list boxes and search button.
session_start();
?>
<!DOCtype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style type="text/css">
a:link {
     color: #000000;
   }

.search{
        position:relative;
        left:730px;
	background-color:transparent;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:1px solid green;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:17px;
	padding:16px 31px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.search:hover {
	background-color:transparent;
}
.search:active {
	position:relative;
	top:1px;
}
.nav{
  background-color:gray;
  padding:4px;
  padding-left:160px;
  color:white;
  font-size:20px;
  border-radius:3px;
}
.body
{
background-color:#f2efec;
}
</style>
<script type="text/javascript">
                                                           /*
                                                            This is ajax function to open php through java script
                                                           */
  function load(thediv,thefile) {
   if(window.XMLHttpRequest){
    xmlhttp = new XMLHttpRequest();
   }else  {
     xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
   }
   xmlhttp.onreadystatechange = function() {
     if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
       document.getElementById(thediv).innerHTML = xmlhttp.responseText;
   }
   }
  xmlhttp.open('GET',thefile,true);
  xmlhttp.send();
   return;
  }
</script>
</head>
<body class="body" onload="load('adiv','sub.php?cat=1');">                 <!--On loading the body function is called to dispaly Categories-->
<div class="nav">
 <form action='search.php' method='GET'>
 <span><big>Xcelerator Project</big></span>
<input type="submit"  class='search' name="search" value="Search Now">     <!--search button-->
 </form>
 </div>                                                                     <!--Divisons to dispaly results-->

<div id="adiv"></div>
<br>
 <ul>
<div id="adiv1"> </div>

 <br>
 <div id="adiv2"></div>
 <br>
 </ul>
<!--Divisons to dispaly results-->

</body>
</html>