<!DOCtype html>
<html lang="en">
                                   <!--This Page is second page and it will display all the search results of products.-->
<head>
<meta charset="UTF-8">
<style>
.SearchBody{
background-color:#f2efec
}
.nav{
  background-color:gray;
  padding:25px;
  padding-left:200px;
  color:white;
  font-size:20px;
  border-radius:3px;
}
.results{
  position:relative;
  background-color:#ffffff;
  left:150px;
  width:1130px;
}
</style
</head>
<body class="SearchBody">
<div class="nav">
<span><big>Search Model - Listing Results</big></span>
</div>
<br>
<div class="results">
<?php
session_start();
require 'connect.inc.php';
function loadProds($query){                 //This is a function to display Products when Category and Subcategory  are not selected.
  if($query_run = mysql_query($query)) {
   if(mysql_num_rows($query_run) == NULL){
      echo 'No results found';
   }else{
     while($query_row = mysql_fetch_assoc($query_run)) {
        $SubcategoryName = $query_row['SubcategoryName'];
        $ProductName = $query_row['ProductName'];
        echo '<br>'.$ProductName.' is '.$SubcategoryName.'<br><br>';
     }
   }
 }
 }
  function loadProd($query){              //This is a function to display Products when Category and Subcategory is selected.
    static $flag=0;
  if($query_run = mysql_query($query)) {
   if(mysql_num_rows($query_run) == NULL){
      echo 'No results found';
   }else{
     while($query_row = mysql_fetch_assoc($query_run)) {
        $SubcategoryName = $query_row['SubcategoryName'];
        $ProductName = $query_row['ProductName'];
        if($flag == 0)
        {
          echo "Search results for '$SubcategoryName' are<br><br>";
        }
        echo '<br>'.$ProductName.' is '.$SubcategoryName.'<br><br>';
        $flag++;
     }
   }
 }
 }
 function loadProdSub($query) {              //This is a function to dispaly Products when Category is selected
   static $flag = 0;
   if($query_run = mysql_query($query)) {
   if(mysql_num_rows($query_run) == NULL){
      echo 'No results found';
   }else{
     while($query_row = mysql_fetch_assoc($query_run)) {
        $CategoryName = $query_row['CategoryName'];
        if($flag == 0 )
        {
          echo "Search results for '$CategoryName' are </br>";
        }
        $SubcategoryName = $query_row['SubcategoryName'];
        $query2 = "SELECT  ProductName , SubcategoryName FROM `table_productlisting` WHERE SubcategoryName='$SubcategoryName'";
         if($query_run1 = mysql_query($query2))  {
           if(mysql_num_rows($query_run1) == NULL) {
             echo '';
           } else {
             while($query_row1 = mysql_fetch_assoc($query_run1))  {
               $SubcategoryName = $query_row1['SubcategoryName'];
               $ProductName = $query_row1['ProductName'];
                echo '<br>'.$ProductName.' is '.$SubcategoryName.'<br><br>';
             }
           }
         }
         $flag++;
       }
     }
    }
   }
   /*
   This part is to call functions under different selections of categories and subcategories
   */
  if((!isset($_SESSION['cric']) && !isset($_SESSION['foot'])) or (isset($_SESSION['cric']) && isset($_SESSION['foot']))) {
    echo "Search result for Product's <br><br>";
   $query="SELECT  ProductName , SubcategoryName FROM `table_productlisting` WHERE 1 " ;
   loadProds($query);
}
 else if(isset($_SESSION['bat'])) {
  $query= "SELECT SubcategoryName , ProductName FROM `table_productlisting` WHERE SubcategoryName='Bat'";
 loadProd($query);
}
else if(isset($_SESSION['stud'])){
   $query= "SELECT SubcategoryName , ProductName FROM `table_productlisting` WHERE SubcategoryName='Stud'";
 loadProd($query);
}else if(isset($_SESSION['shinpad'])){
   $query= "SELECT SubcategoryName , ProductName FROM `table_productlisting` WHERE SubcategoryName='Shinpads'";
 loadProd($query);
}
else if(isset($_SESSION['cric'])) {
  $query="SELECT DISTINCT CategoryName ,SubcategoryName FROM `table_subcategory` WHERE CategoryName='Cricket'";
  loadProdSub($query);
}
else if(isset($_SESSION['foot'])) {
 $query="SELECT DISTINCT CategoryName , SubcategoryName FROM `table_subcategory` WHERE CategoryName='FootBall'";
  loadProdSub($query);
}
else {
  echo 'Invalid Choice';
}
?>
<?php
session_destroy();
?>
</div>
</body>
 </html>
