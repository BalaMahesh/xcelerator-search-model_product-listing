<!DOCtype html>
<html lang="en">
                                 <!--This  is intermediate between first page and second page.
                                 It will contain functions to display Categories and Subcategories and to select Categories and Subcategories.
                                 -->
<head>
<meta charset="UTF-8">
<style>
.cat {
   position:relative;
   background-color:#ffffff;
   width:160px;
   top:100px;
   left:20px;
   white-space:nowrap;
   color:black;
   overflow:hidden;
   text-overflow:ellipsis;
   }
   ul
   {
     list-style-type : none;
     color:black;
   }
   .cat li a {
    color:black;
  }
  .cat li a:hover{
    color:#0087e6;
  }
 .sub {
   position:relative;
   background-color:#ffffec;
   width:100px;
   left:180px;
   bottom:72px;
   padding-left:50px;
   padding-top:10px;
   text-align:left;
   white-space:nowrap;
   color:black;
   overflow:hidden;
   text-overflow:ellipsis;
   }
 ul{
   list-style-type:none;
   }
  .sub li a
  {
    color:black;
  }
  .sub li a:hover{
    color:#b81e23;
    text-decoration:underline;
  }
  </style>
</head>
<body>
<?php
session_start();                                     //Session Variables to keep the information of selected Categories and Subcategories .
require 'connect.inc.php' ;
function loadSub($query,$a)                         //This is a function to dispaly SubcategoryNames from database using php.
{
    echo '<div class="sub">';
  if($query_run = mysql_query($query)) {
   if(mysql_num_rows($query_run) == NULL){
      echo 'No results found';
   }else{
     while($query_row = mysql_fetch_assoc($query_run)) {
        $SubcategoryName = $query_row['SubcategoryName'];
          echo '<div class="sub'.$a.'"><li><a href="#" onclick = load("bdiv'.$a.'","sub.php?prod='.$a.'")>'.$SubcategoryName.'</li></a></div></br>';
        $a++;

     }
     echo '</div>';
   }

 }else {
      echo mysql_error();
    }

}
if(isset($_GET['prod'])) {                      // This is to know which SubCategory is selected
  $num = $_GET['prod'];
 switch ($num) {
  case 1:
  $_SESSION['bat'] = 1;
  break;
  case 2:
  $_SESSION['stud'] = 1;
  break;
  case 3:
  $_SESSION['shinpad'] = 1;
  break;
 }
}

else if(isset($_GET['subcat'])) {                //This is to call a function to display SubCategories if Category is selected.
  $num = $_GET['subcat'];
 switch ($num) {
  case 1:
  $_SESSION['cric'] = 1;
 $query="SELECT SubcategoryName FROM `table_subcategory` WHERE CategoryName='Cricket'";
 loadSub($query,1);
  break;
  case 2:
   $_SESSION['foot'] =1;
  $query="SELECT SubcategoryName FROM `table_subcategory` WHERE CategoryName='FootBall'";
  loadSub($query,2);
  break;
 }
}
else if(isset($_GET['cat'])) { // This is to display Categories when function from first page is called.
require 'connect.inc.php' ;
 $query="SELECT DISTINCT CategoryName FROM `table_subcategory` WHERE 1 " ;
 if($query_run = mysql_query($query)) {

   if (mysql_num_rows($query_run) == NULL) {
      echo 'No results Found';
   }else {
          echo '<div class="cat">';
          echo '<ul>';
          echo '<span>Categories</span><br>';
  while($query_row = mysql_fetch_assoc($query_run)) {
    static $i=1;
    $CategoryName = $query_row['CategoryName'];
     echo '<br><li><a href="#/" id="cat'.$i.'" onclick=load("adiv'.$i.'","sub.php?subcat='.$i.'")>'.$CategoryName.'</a></li><br>';
     $i++;
  }
  echo '</ul>';
  echo '</div>';
    }
    }else {
   echo mysql_error();
 }
   }
?>
</body>
</html>
