-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2017 at 04:18 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `table_productlisting`
--

CREATE TABLE `table_productlisting` (
  `PrimaryKey` int(11) NOT NULL,
  `ProductName` varchar(20) NOT NULL,
  `SubcategoryName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_productlisting`
--

INSERT INTO `table_productlisting` (`PrimaryKey`, `ProductName`, `SubcategoryName`) VALUES
(1, 'Kookabura', 'Bat'),
(2, 'MT', 'Bat'),
(3, 'Yonex', 'Stud');

-- --------------------------------------------------------

--
-- Table structure for table `table_subcategory`
--

CREATE TABLE `table_subcategory` (
  `PrimaryKey` int(11) NOT NULL,
  `CategoryName` varchar(20) NOT NULL,
  `SubcategoryName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_subcategory`
--

INSERT INTO `table_subcategory` (`PrimaryKey`, `CategoryName`, `SubcategoryName`) VALUES
(1, 'Cricket', 'Bat'),
(2, 'FootBall', 'Stud'),
(3, 'FootBall', 'ShinPads');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `table_productlisting`
--
ALTER TABLE `table_productlisting`
  ADD PRIMARY KEY (`PrimaryKey`);

--
-- Indexes for table `table_subcategory`
--
ALTER TABLE `table_subcategory`
  ADD PRIMARY KEY (`PrimaryKey`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `table_productlisting`
--
ALTER TABLE `table_productlisting`
  MODIFY `PrimaryKey` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `table_subcategory`
--
ALTER TABLE `table_subcategory`
  MODIFY `PrimaryKey` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
